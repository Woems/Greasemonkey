// ==UserScript==
// @name           Wurzelimperium - Select Login Server (nach Zeit)
// @namespace      Woems
// @include        http://*wurzelimperium.de/*
// ==/UserScript==

function $(id) {
  return document.getElementById(id);
}

function $x(p, context) {
  if (!context) context = document;
  var i, arr = [], xpr = document.evaluate(p, context, null, XPathResult.UNORDERED_NODE_SNAPSHOT_TYPE, null);
  for (i = 0; item = xpr.snapshotItem(i); i++) arr.push(item);
  return arr;
}

function deserialize(name, def) {
  return eval(GM_getValue(name, (def || '({})')));
}

function serialize(name, val) {
  GM_setValue(name, uneval(val));
}

function date2text(date)
{
  var last=new Date(date*1000);
	return last.getDate() + "." + last.getMonth() + "." + last.getFullYear() + " " + last.getHours() + ":" + last.getMinutes() + "." + last.getSeconds();
}


/////////////////////////////////////////////////////
/////////////////////////////////////////////////////
/////////////////////////////////////////////////////
/////////////////////////////////////////////////////

var loc = document.location; 
var reg = /http:\/\/s(.*?)\.wurzelimperium\.de\/(.*?)\.php/i;
if (reg.exec(loc))
{
  var server = reg.exec(loc)[1];
  var page = reg.exec(loc)[2];
} else {
  var server = "";
  var page = "";
}

switch (page) {
case "" : do_login();break;
case "main"	  : do_main();break;
case "garten_map" : do_garten_map(); window.addEventListener('unload',function () { do_garten_map(); }, true); break;
case "verkauf_map": do_verkauf_map();break;
}

function do_verkauf_map()
{

}

function do_garten_map()
{
  var lasttime = 9999999999;
  src=document.getElementsByTagName('SCRIPT')[0].innerHTML;
  regex=/garten_zeit\[([0-9]*)\] = ([0-9]*)/g;
  var Gartenzeiten=src.match(regex);
  for(var i=0 ;i< Gartenzeiten.length;i++){
  	Zeit=regex.exec(Gartenzeiten);
	  if (lasttime > 	Zeit[2] && Zeit[2]!=0)
      lasttime=Zeit[2];
  }
  var jetzt = new Date();
  if (lasttime == 9999999999)
    lasttime=Math.round(jetzt.getTime()/1000).toString();
  var Serverzeit=deserialize("zeit");
  Serverzeit[server]=lasttime;
  //GM_log(uneval(Serverzeit));
  serialize("zeit",Serverzeit);

  var Timer=jetzt.getTime()-lasttime*1000;
  if (Timer>2000)
  window.setTimeout(function () {
    alert("Achtung");
  }, Timer+10000);

  window.addEventListener('unload',function () {
    var lasttime = 9999999999;
    src=document.getElementsByTagName('SCRIPT')[0].innerHTML;
    regex=/garten_zeit\[([0-9]*)\] = ([0-9]*)/g;
    var Gartenzeiten=src.match(regex);
    for(var i=0 ;i< Gartenzeiten.length;i++){
  	Zeit=regex.exec(Gartenzeiten);
	  if (lasttime > Zeit[2] && Zeit[2]!=0)
      lasttime=Zeit[2];
    }
    var jetzt = new Date();
    if (lasttime == 9999999999)
      lasttime=Math.round(jetzt.getTime()/1000).toString();
    var Serverzeit=deserialize("zeit");
    Serverzeit[server]=lasttime;
    //GM_log(uneval(Serverzeit));
    serialize("zeit",Serverzeit);
  }, true)
}

function do_main()
{
  var jetzt = new Date();
  var lastServer=deserialize("last");
  lastServer[server]=jetzt.getTime();
  serialize("last",lastServer);
  
  var Serverzeit=deserialize("zeit");
  var ausgabe="";
  for(var i in Serverzeit)
  {
    if (i==server)
      ausgabe+="<b>Server "+i+": "+date2text(Serverzeit[i])+"</b><br>";
    else
      ausgabe+="Server "+i+": "+date2text(Serverzeit[i])+"<br>";
  }
      
  var div=document.createElement("div");
  div.innerHTML=ausgabe;
  document.body.appendChild(div);
}

function do_login()
{
  // Server, der am l�ngsten nicht benutzt wurde, suchen
  var lastServer=deserialize("zeit");
  var date=0;
  var server=0;
  //GM_log(uneval(lastServer));
  for (var i in lastServer)
  {
    if (lastServer[i]<date || date==0)
    {
      date=lastServer[i];
	    server=i;
    }
  }

  // ID f�r das Auswahlmen� der Server setzen
  if ($x('//select[@class="loginput link"][@name="server"]')[0])
    $x('//select[@class="loginput link"][@name="server"]')[0].id="serverlist";

  // Server ausw�hlen
  $x('id("serverlist")/option').forEach(function (option) {
    if (option.value=="server"+server)
      option.selected=true;
  });
}
