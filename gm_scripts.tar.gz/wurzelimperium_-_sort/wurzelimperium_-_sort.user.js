// ==UserScript==
// @name           Wurzelimperium - Sort
// @namespace      Woems
// @description    Sortiert die Gl�ser
// @include        http://s*.wurzelimperium.de*
// ==/UserScript==

function $(id) {
  return document.getElementById(id);
}

function $x(p, context) {
  if (!context) context = document;
  var i, arr = [], xpr = document.evaluate(p, context, null, XPathResult.UNORDERED_NODE_SNAPSHOT_TYPE, null);
  for (i = 0; item = xpr.snapshotItem(i); i++) arr.push(item);
  return arr;
}

function createElement(type, attributes){
 var node = document.createElement(type);
 for (var attr in attributes) if (attributes.hasOwnProperty(attr)){
  node.setAttribute(attr, attributes[attr]);
 }
 return node;
}
/*
Example usage:
var styles = createElement('link', {rel: 'stylesheet', type: 'text/css', href: basedir + 'style.css'});
document.body.previousSibling.appendChild(styles);
*/

var loc = document.location; 
var reg = /http:\/\/s(.*?)\.wurzelimperium\.de\/(.*?)\.php/i;
var server = reg.exec(loc)[1];
var page = reg.exec(loc)[2];

switch (page) {
case "main"	  : do_main();break;
case "garten_map" : do_garten_map();break;
case "verkauf_map": do_verkauf_map();break;
default: GM_log(page); break;
}

function swapPos(a, b)
{
  var top=a.style.top;
  var left=a.style.left;
  a.style.top=b.style.top;
  a.style.left=b.style.left;
  b.style.top=top;
  b.style.left=left;
}

function getAnzahl(bottle)
{
  return $x("div[3]/div",bottle)[0].innerHTML;
}

45

function do_main()
{
  window.setInterval(function () {
  var bottles=$x("id('rackItems')/div");
  var bottlesPos=new Array();
  for (var i=0; i<bottles.length; i++)
    bottlesPos[((bottles[i].style.top.replace(/px/,"")-25)/75*4+(bottles[i].style.left.replace(/px/,"")-22)/45)]=i;
  for (var i=1; i<bottlesPos.length; i++)
    if ( getAnzahl(bottles[bottlesPos[i-1]])*1 > getAnzahl(bottles[bottlesPos[i]])*1 )
    {
      swapPos(bottles[bottlesPos[i-1]],bottles[bottlesPos[i]]);
      var tmp=bottlesPos[i-1];
      bottlesPos[i-1]=bottlesPos[i];
      bottlesPos[i]=tmp;
      //GM_log(bottlesPos+" "+getAnzahl(bottles[bottlesPos[0]])+" "+getAnzahl(bottles[bottlesPos[1]])+" "+getAnzahl(bottles[bottlesPos[3]]));
      i=0;
    }
  },5000);
}
function do_garten_map()
{
}
function do_verkauf_map()
{
}

